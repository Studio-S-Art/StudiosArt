import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import AboutSection from "@/components/AboutSection";
import GallerySection from "@/components/GallerySection";
import TestimonialsSection from "@/components/TestimonialsSection";
import FAQSection from "@/components/FAQSection";
import ContactSection from "@/components/ContactSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import ScrollToTopButton from "@/components/ScrollToTopButton";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>Zapinnovative | Professional IT Repair Services - Laptops, Computers & Printers</title>
        <meta 
          name="description" 
          content="Fast & reliable IT repair services for laptops, computers, printers & more. Free diagnostic, 2-year warranty, same-day service available. Zapinnovative." 
        />
        <meta name="keywords" content="laptop repair, computer repair, printer repair, IT services, data recovery, screen replacement, hardware upgrade" />
        <link rel="canonical" href="https://zapinnovative.com" />
      </Helmet>

      <main className="min-h-screen bg-background">
        <Navbar />
        <HeroSection />
        <ServicesSection />
        <AboutSection />
        <GallerySection />
        <TestimonialsSection />
        <FAQSection />
        <ContactSection />
        <CTASection />
        <Footer />
        <WhatsAppButton />
        <ScrollToTopButton />
      </main>
    </>
  );
};

export default Index;
